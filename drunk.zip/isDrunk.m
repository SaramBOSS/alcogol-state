function I = isDrunk(accCsvPath,gyroCsvPath, resultPath)
%addpath('./Alcoholic');
%dir('./Alcoholic')
%addpath('./Alcoholic/Test/');


%wd '/home/lab/Рабочий стол/amalthea_server/amalthea_server/amalthea/libs/drunk_state_recognition/Alcoholic'
% accTable = readtableaccCsvPath)
% gyroTable = readtable(gyroCsvPath)
accCsvPath = '/home/lab/Рабочий стол/amalthea_server/amalthea_server/amalthea/libs/drunk_state_recognition/data_acc.csv';
gyroCsvPath = '/home/lab/Рабочий стол/amalthea_server/amalthea_server/amalthea/libs/drunk_state_recognition/data_gyro.csv';
resultPath = '/home/lab/Рабочий стол/amalthea_server/amalthea_server/amalthea/libs/drunk_state_recognition/Test.txt';

isTrained = true; %true = модель уже обучена, false = модель не обучена

warning('off');
rmpath('ModifiedAndSavedVarnames');  

if(isTrained == false)
    
    delete 'sober.csv'
    delete 'alchogolic.csv'
    
    Getting_signs(fs, way, 3, 24, 'Data')
    Getting_signs(fs, way, 4, 4, 'My_Data')
    
    
    
    soberData = readtable('sober.csv');
    alchogolicData = readtable('alchogolic.csv');
    Training_data = [soberData; alchogolicData];
    
    [trainedClassifier, validationAccuracy] = trainClassifier(Training_data);
   
    save('trainedClassifierSave.mat', 'trainedClassifier');
    
else
    
    delete 'Test.csv'
    
    load('trainedClassifiersave.mat', 'trainedClassifier');
    
    i = 0;
    zerogyro = gyroCsvPath(2, 2);
    
    while(gyroCsvPath(2, i) * 1000 < zerogyro * 1000 + 10)   
       norm(gyroCsvPath); %Нужно чтобы отдельно запускался 
       i=i+1;
    end 
    test(accCsvPath, gyroCsvPath);
    
    Test = readtable('Test.csv');
    yfit = trainedClassifier.predictFcn(Test);
    
    
    



I = num2str(yfit);
fid = fopen(resultPath, 'w');
fwrite(fid,I);
fclose(fid);

end