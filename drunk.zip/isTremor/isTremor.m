function I = isTremor(accCsvPath, gyroCsvPath, resultPath)

resultPath = './result.txt';
accCsvPath = './data_acc.csv';

%import features
addpath('./featurePacks');
%include model
load('model1.mat');

%предобработка
%извлечение признаков
%отправка на классификатор

%accTable = readtable(accCsvPath);
%BaggedTreesModel001
%gyroTable = readtable(gyroCsvPath);

I = '1';
fid = fopen(resultPath, 'w');
fwrite(fid, I);
fclose(fid);
    
end