function featVec = getMaxMedianFeatureVec(data, nFeat)
%data -- vector of data
nFeatInWin = 2;
featVec(1:nFeat) = 0;
winLen = floor(length(data)/(nFeat/nFeatInWin));
idx(1) = 1;
idx(2) = idx(1) + winLen - 1;
for j = 1:nFeatInWin:nFeat
    A_win = data(idx(1):idx(2));
    featVec(j) = max(A_win);
    featVec(j+1) = featVec(j) - median(A_win);
    idx = idx + winLen;
end
    
end