function feats = get4ShapeStatisticalMomentsFeatures(data, isAdduct)
%isAdduct (true of false) -- adduct or dont adduct
feats(1:4) = 0;

N = length(data);
S = sum(data);  

%data = data';
%a = data;
%b = (1:N);
%c = a.*b;
%d = sum(c);
feats(1) = sum(data.*(1:N));
%a = ((1:N) - mu).^2;
%b = data;
feats(2) = sqrt(sum(((1:N) - feats(1)).^2 .* data)/S);
feats(3) = sum((((1:N)-feats(1))/feats(2)).^3 .* data)/S;%skewness
feats(4) = sum((((1:N)-feats(1))/feats(2)).^4 .* data)/S - 3;%curtosis

% feats(1) = mean(data);
% feats(2) = std(data);
% feats(3) = sum(((data - mu)/sigma).^3)/length(data);
% feats(4) = sum(((data - mu)/sigma).^4)/length(data) - 3;

if isAdduct
    feats(3) = feats(3).^(1/3);
    feats(4) = (feats(4)+3).^(1/4);
end

end