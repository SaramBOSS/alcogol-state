function feats = get4StatisticalMomentsFeatures(data, isAdduct)
%isAdduct (true of false) -- adduct or dont adduct
feats(1:4) = 0;

feats(1) = mean(data);
feats(2) = std(data);
feats(3) = sum(((data - feats(1))/feats(2)).^3)/length(data);%skewness
feats(4) = sum(((data - feats(1))/feats(2)).^4)/length(data) - 3;%curtosis

if isAdduct
    feats(3) = feats(3).^(1/3);
    feats(4) = (feats(4)+3).^(1/4);
end

end