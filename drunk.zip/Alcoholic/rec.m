function rec()
a = 1
end